<?php
$conexion=new mysqli("localhost","root","","usuarios");
$conexion->set_charset("utf8");
?>