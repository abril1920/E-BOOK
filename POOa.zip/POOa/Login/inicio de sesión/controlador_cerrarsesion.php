<?php

session_start();
session_destroy();
header("location: ../inicio%20de%20sesión/inicio_sesion.php");
?>  